# 必须安装的插件

  - EsLint
  - GitLens
  - Vetur
  - JavaScript (ES6) code snippets
  
# 推荐的插件

  - Bracket Pair Colorizer
  - Path Intellisense
  - Beautify

# eslint配置

  为了规范代码风格，前端项目都有通过eslint来检查，并设置自动修复。

  1. 开启eslint，并勾选自动修复。
   
  ![](images/vscode准备/1.png)

  在保存文件时，执行eslint检查

  ![](images/vscode准备/2.png)

  2.在vscode的settings.json中，加上对vue的检查。

  进入 eslint.validate的设置

  ![](images/vscode准备/3.png)

  把eslint.validate 改成以下内容

    ```
      "eslint.validate": [
        "javascript", {
          "language": "vue",
          "autoFix": true
        },
        "javascriptreact"
      ]
    ```

# vue-devtools安装

[安装链接](https://github.com/vuejs/vue-devtools)

