# 说明

采用gitflow的流程来进行协作开发。

# 准备工作
## git
本地开发环境已经装好git，并配置了用户名和邮箱
```
  git config user.name 'xxx'
  git config user.email 'email'
```

## 插件
- vscode 安装好了  GitLens 插件
  
  安装好后vscode左侧菜单栏会多一个菜单(只有在当前打开的目录是git仓库时才会出现)

   ![](images/GIT Flow操作规范[vscode]/1.png)


## 检出项目

 - 通过命令或是其他gui软件检出项目后，再用vscode打开。
  
  ```
    git clone http://gitlab.startsi.cn/xxx/xxx.git
  ```
 - 在vscode中通过命令导入。

    按住 Ctrl + Shift + P 调出vscode的命令行工具，选中git clone 命令后，输入仓库地址，vscode会帮你clone项目后打开。

  初始项目一般会有master, develop两个分支，但是项目刚检出的时候，其实会发现本地只有一个master分支，这时可以先抓取(fetch)远程分支
  ```
    git fetch
  ```
  这时就可以通过GitLens就可以看到远程的其他分支了(以后别人添加的远程分支也可以通过抓取看到)。然后再把远程分支检出到本地，这样本地也有develop分支了。检出方式有多种，这里介绍一个:
  ```
  git checkout -b xxx origin/xxx
  ```

# 开发新功能

## 步骤
  
  1. 从develop分支中新建一个功能分支，命名规范为 ***feature/xxx***;
  2. 在该分支中进行功能开发，过程中可随时提交到远程仓库;
  3. 开发完成后，需要和develop分支进行合并，保证是最新的代码；
  4. 合并完成后，在gitlabz中发起请求合并。
   
## 新建分支
  从gitlens的管理窗口创建分支

  ![](images/GIT Flow操作规范[vscode]/2.png)
  
  在输入分支名称后，可以在控制台看到git命令
  ```
  git branch feature/map develop
  ```

  也可以通过命令
  ```
  git checkout -b feature/map 
  ```

  也就是全部操作都可以直接通过命令来操作，也可以通过其他git的图形化界面完成。下同。

## 功能开发
### 切换到feature/map分支进行开发

  ![](images/GIT Flow操作规范[vscode]/3.png)

  提交更改，先把更改过后的文件提交到暂存区，该操作可以通过命令 ``` git add . ```,也可以通过vscode左侧的源代码管理:git的窗口进行。

  ![](images/GIT Flow操作规范[vscode]/4.png)

  提交修改操作可以通过命令 ``` git commit -m 'xxxxx' ```，也可以在上图中的消息框输入提交信息后提交。

### 提交到远程仓库

  通过命令提交到远程仓库 ``` git push origin feature/map ```

  登陆gitlab控制台就可以看到该分支已经提交到远程仓库了

  ![](images/GIT Flow操作规范[vscode]/5.png)

  当另一个开发人员也要在该分支上开发时，本地又没有该分支时，需要先同步远程版本到本地。可以通过命令``` git fetch ``` 完成同步（不会自动merge），然后通过 ``` git checkout -b xxx(本地分支名) origin/远程分支名 ``` 拉去新的分支到本地；或是直接 ``` git pull origin <远程分支名>:<本地分支名> ```(这种情况只有合并是快进的时候才可以)。

### 合并请求

  再申请合并请求之前，先需要合并最新的develop代码后再申请。有以下两个方法：
  - 先切到 develop 分支 ``` git checkout develop ``` ,通过 ``` git pull origin develop ``` 更新本地develop分支，这时本地的develop分支已经是最新的了。
  再切回功能分支后，通过 ``` git merge develop ``` 合并分支，解决冲突后（如果存在），提交到远程仓库。

  - 通过命令 ``` git pull origin <远程分支名>:<本地分支名> ``` ，比如这里就可以执行 ``` git pull origin develop:feature/map ```,这样就可以让feature/map合并远程的develop代码。
### 发起合并请求

  ![](images/GIT Flow操作规范[eclipse]/11.png)

  ![](images/GIT Flow操作规范[eclipse]/12.png)

  ![](images/GIT Flow操作规范[eclipse]/13.png)

  ![](images/GIT Flow操作规范[eclipse]/14.png)

  最后等待项目管理人员通过请求即可。

  

