# 准备

  采用gitflow的流程来进行协作开发。

- 已经拥有账号，并拥有developer角色
- 检出目标项目
- eclipse 安装好了git插件
  
  1. 通过 git 命令从指定的链接clone项目，然后导入eclipse项目中
    
     ```
     http://gitlab.startsi.cn/xxx/ephoto.git
     ```
  2. 通过git插件直接在eclipse 中引入项目
  
      ![](images/GIT Flow操作规范[eclipse]/1.png)
      
      ![](images/GIT Flow操作规范[eclipse]/2.png)

      ![](images/GIT Flow操作规范[eclipse]/3.png)

      ![](images/GIT Flow操作规范[eclipse]/4.png)

      ![](images/GIT Flow操作规范[eclipse]/5.png)

      **注意：这样导入的项目还要手动转换成maven项目。**
    
  这样项目就已经导入成功了。

# 开发新功能

  从dev分支上创建一个新的功能分支 **feature/funtionx** (分支命名规范必须是 **feature/xxx** ) 

![](images/GIT Flow操作规范[eclipse]/6.png)

从eclipse 中可以看出，项目已处于feature分支

![](images/GIT Flow操作规范[eclipse]/7.png)

开发过程中可以把分支提交到远程库中，如下图，需要提交的文件放到暂存区(**Staged Changes**)，然后写上提交信息后点击**Commit**或是**Commit and Push**，后者会顺便提交到远程库里。

![](images/GIT Flow操作规范[eclipse]/8.png)

可以看到，已经提交到远程库里了。

![](images/GIT Flow操作规范[eclipse]/9.png)

如果该功能分支是多人协作的，也许远程库的版本会更新，这时需要先拉取远程库的文件，合并后再提交。

# 合并请求

开发完成并测试没有问题之后，需要申请合并到dev分支。

因为开发人员没有操作master和dev分支的权限，所以必须在网页控制台发起功能分支合并到dev分支的请求。

这时有两种情况：
 - 当前的dev版本在你新建分支后没有其他人合并过,这种单线的历史分支不存在任何需要解决的分歧,这时的合并过程称作**fast forward**
 - 已经有别的功能分支合并过了
  
第一种情况，直接把完成后的功能分支代码提交到远程库中，再发起合并请求即可； 

第二种情况，就要先合并最新的**dev分支**的代码后再请求合并。先切回**dev分支**中，拉取远程库的代码确保dev是最新的代码，再切回**feature/functionX**执行**merge**操作，把**dev分支**合并到**feature/functionX**中；也可在**feature/functionX**分支中直接合并远程库的**dev分支**，两种方式都可以。

![](images/GIT Flow操作规范[eclipse]/10.jpg)

但是为了确保代码的正确，最好直接按第二种情况执行。

发起合并请求

![](images/GIT Flow操作规范[eclipse]/11.png)

![](images/GIT Flow操作规范[eclipse]/12.png)

![](images/GIT Flow操作规范[eclipse]/13.png)

![](images/GIT Flow操作规范[eclipse]/14.png)

最后等待项目管理人员通过请求即可。



